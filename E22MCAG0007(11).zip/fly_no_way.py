# E22MCAG0007
# Namoju sumanth
from fly_behavior import FlyBehavior

class FlyNoWay(FlyBehavior):
    def fly(self):
        print("It cannot fly,Unable to fly")

