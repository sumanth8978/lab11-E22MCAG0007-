# E22MCAG0007
# Namoju sumanth
from fly_behavior import FlyBehavior

class FlyWithWings(FlyBehavior):
    def fly(self):
        print("Flying with wings")
